import { useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css'
import './App.css'

function App() {
  const [value, setValue] = useState('')

  const handleClick = (e) => {
    setValue(value + e.target.value)
  }

  return (
    <div className="container d-flex justify-content-center align-items-center min-vh-100">
      <div className="calculator border p-4 rounded shadow bg-light w-100" style={{ maxWidth: '400px' }}>
        <form>
          <div className="mb-3">
            <input
              type="text"
              className="form-control text-end fs-4"
              value={value}
              readOnly
            />
          </div>

          <div className="row g-2 mb-2">
            <div className="col"><input type="button" value="AC" className="btn btn-danger w-100" onClick={() => setValue('')} /></div>
            <div className="col"><input type="button" value="DE" className="btn btn-warning w-100" onClick={() => setValue(value.slice(0, -1))} /></div>
            <div className="col"><input type="button" value="." className="btn btn-secondary w-100" onClick={handleClick} /></div>
            <div className="col"><input type="button" value="/" className="btn btn-secondary w-100" onClick={handleClick} /></div>
          </div>

          {[
            ['7', '8', '9', '*'],
            ['4', '5', '6', '+'],
            ['1', '2', '3', '-'],
            ['0', '=']
          ].map((row, rowIndex) => (
            <div className="row g-2 mb-2" key={rowIndex}>
              {row.map((btnVal, colIndex) => (
                <div className="col" key={colIndex}>
                  {btnVal !== '' ? (
                    <input
                      type="button"
                      value={btnVal}
                      className={`btn ${btnVal === '=' ? 'btn-primary' : 'btn-secondary'} w-100`}
                      onClick={
                        btnVal === '='
                          ? () => {
                              try {
                                setValue(eval(value).toString())
                              } catch {
                                setValue('Error')
                              }
                            }
                          : handleClick
                      }
                    />
                  ) : null}
                </div>
              ))}
            </div>
          ))}
        </form>
      </div>
    </div>
  )
}

export default App
